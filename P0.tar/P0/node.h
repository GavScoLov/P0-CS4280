#ifndef NODE_H
#define NODE_H

typedef struct node_t {
	int key;
	char word[100];
	struct node_t *leftNode;
	struct node_t *rightNode;
} node_t;

#endif
