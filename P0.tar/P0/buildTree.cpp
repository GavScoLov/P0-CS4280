#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cctype>

#include "buildTree.h"
#include "node.h"
#include "traversals.h"

using namespace std;

// Insert String into BST
void insert(BSTNode*& root, const string& str) {
	if(root == NULL){
		root = new BSTNode(str);
	}else if(str < root->data){
		insert(root->left, str);
	}else{
		insert(root->right, str);
	}
}

// Build BST from NodeArr
void buildBST(const string nodeArr[], int n, BSTNode*& root){
	for(int i = 0; i < n; ++i){
		insert(root, nodeArr[i]);
	}
}

node_t *buildTree(char* file, char* baseFile, int valC){
	// Declare Variables
	int x = 0, i = 0, j = 0, k = 0, a = 0, b = 0, d = 0;
	int unique = 0, tempInt = 0, wordInd = 0, wordComp = 0;
	bool found = false;
	char fileData;
	string tempLtr, tempWord, tempCharString;
	bool alpha[26] = {false}; // Array of T/F Flags
	char fileArr[MAX];
	char fileWord[MAX];
	string inputChar;
	string inputWord[MAX];
	char capitalLtr[MAX]; 	// Array of Capital Letters
	string words[MAX]; 	// Array of Words from File
	string nodeArr[MAX];	// Array of Nodes that contain '<CapitalLetters>: <Words>'
	// Keyboard Input handled here:
	if(valC == 1){
		cout << "Keyboard Input: " << endl;
		getline(cin, inputChar);
		//cout << inputChar;
		for(x = 0; x < (inputChar.size()); x++){
			fileArr[x] = inputChar[x];
		}
		tempInt = x;
		strcpy(baseFile,"out");
		// Convert each character array element into a string
		while (inputChar[i] != '\0') {
			if (inputChar[i] == ' ') {
				words[k++].assign(words[k], 0, a); // Assign the word to the string array
				a = 0; // Reset index for the next word
			} else {
				words[k].push_back(inputChar[i]); // Add character to the current word
				a++;
			}
			i++;
		}
		words[k].assign(words[k], 0, a); // Assign the last word
	}else{
		cout << "File Opening" << endl;
		// Open File for Reading
		FILE *filePtr = fopen(file, "r");
		// Check if file opened correctly
		if(filePtr){
			// Read words separated by WS into an array of strings
			while(fscanf(filePtr, " %s", fileWord) == 1 && k < MAX){
				words[k] = fileWord;
				k++;
			}
			// Rewind file pointer
			rewind(filePtr);
			cout << "File Arr: ";
			// Loop through file and store each character into 'fileArr'	
			while(fscanf(filePtr, "%c", &fileData) == 1){
				fileArr[x] = fileData;
				cout << fileArr[x];
				x++;
			}
			tempInt = x;
		}else{
			cout << "ERROR: File Failed to Open" << endl;
		}
		fclose(filePtr);
	}
	for(int z = 0; z < tempInt; z++){	
		// Reset Found to True if WS is found
		if(isspace(fileArr[z])){
			/*for(wordInd; wordInd < z; wordInd++){
			  words[wordComp].push_back(fileArr[wordInd]);
			  }
			  wordInd = z;
			  wordComp++;*/
			found = false;
		}
		// Store all Capital Letters into 'capitalLtr'
		else if(isupper(fileArr[z]) && found == false){
			unique = fileArr[z] - 'A';
			// Check if Capital Letter already exists
			if(!alpha[unique]){
				capitalLtr[j] = fileArr[z];
				alpha[unique] = true;
				found = true;
				j++;
			}
		}else{
			// Check for Special Characters
			for(int spchar = 0; spchar < z; spchar++){
				int ascii = fileArr[z];
				if(ascii == 0 || ascii == 10){
					break;
				}else if(ascii >= 48 && ascii <= 57){
				}else if(ascii >= 65 && ascii <= 90){
				}else if(ascii >= 97 && ascii <= 121){
				}else{
					cout << "ERROR: String input contains special character(s)" << endl;
					return 0;
				}
			}
		}
	}
	for (a = 0; a < j; a++) { // Loop through capital letters
		for (b = 0; b < k; b++) { // Loop through words
			// Loop through the letters in the word
			for (size_t c = 0; c < words[b].length(); c++) {
				if (words[b][c] == capitalLtr[a]) {
					// Loop through Node Array
					for(int index = 0; index < (a + 1); index++){
						if(capitalLtr[a] == nodeArr[index][0]){
							tempWord = " " + words[b];
							nodeArr[index] = nodeArr[index] + tempWord;
						}
					}
					tempLtr = capitalLtr[a];
					tempWord = words[b];
					if(nodeArr[a].empty()){
						nodeArr[a] = tempLtr + ": " + tempWord;
					}
				}
			}
		}
		cout << "Node Array: " << nodeArr[a] << endl;
	}
	//cout << "There" << endl;
	// Variables for Building Binary Search Tree:
	char preFile[MAX];
	char postFile[MAX];
	char levelFile[MAX];

	BSTNode* root = NULL;
	buildBST(nodeArr, a, root);

	strcpy(preFile, baseFile);	
	strcat(preFile, ".preorder");
	FILE* traversalFilePtr = fopen(preFile, "w");
	if(!traversalFilePtr){
		cout << "ERROR: File did not open properly" << endl;
	}
	traversePreOrder(root, 0, traversalFilePtr);
	fclose(traversalFilePtr);

	strcpy(postFile, baseFile);
	strcat(postFile, ".postorder");
	traversalFilePtr = fopen(postFile, "w");
	if(!traversalFilePtr){
		cout << "ERROR: File did not open properly" << endl;
	}
	traversePostOrder(root, 0, traversalFilePtr);
	fclose(traversalFilePtr);

	strcpy(levelFile, baseFile);
	strcat(levelFile, ".levelorder");
	traversalFilePtr = fopen(levelFile, "w");
	if(!traversalFilePtr){
		cout << "ERROR: File did not open properly" << endl;
	}
	traverseLevelOrder(root, 0, traversalFilePtr);
	fclose(traversalFilePtr);
	}

