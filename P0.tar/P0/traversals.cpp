#include <iostream>
#include <cstring>
#include <cstdio>
#include <fstream>
#include <string>

#include "node.h"
#include "buildTree.h"
#include "traversals.h"

using namespace std;

/*
 * Level Order Tree - https://www.geeksforgeeks.org/print-level-order-traversal-line-line/
 * 
 * 
 */

// Height of the tree
int height(BSTNode* node){
	if(node == NULL){
		return 0;
	}else{
		// Find the Height of Left & Right Subtrees
		int lheight = height(node->left);
		int rheight = height(node->right);
		// Use Bigger Subtree for Level-Order
		/*if(lheight > rheight){
			return(lheight + 1);
		}else{
			return(rheight + 1);
		}*/
		return 1 + max(lheight, rheight);
	}
}

// Traversals:
// Preorder Traversal:
void traversePreOrder(BSTNode* root, int level, FILE* file){
	if(root != NULL){
		fprintf(file, "%*d:%s\n", level * 4, level, root->data.c_str());
		traversePreOrder(root->left, level + 1, file);
		traversePreOrder(root->right, level + 1, file);
	}
}

// Postorder Traversal:
void traversePostOrder(BSTNode* root, int level, FILE* file){
	if(root != NULL){
		traversePostOrder(root->left, level + 1, file);
		traversePostOrder(root->right, level + 1, file);
		fprintf(file, "%*d:%s\n",level * 4, level, root->data.c_str());
	}
}

// Levelorder Traversal:
void traverseLevelOrder(BSTNode* root, int i, FILE* file){	
	int bstHeight = height(root);
	for(i = 0; i <= bstHeight; i++){
		printLevelOrder(root, i, file, i);
	}
}

// Print Levelorder:
void printLevelOrder(BSTNode* root, int level, FILE* file, int currentLevel = 0){
	if(root == NULL){
		return;
	}
	if(level == 1){
		for(int i = 0; i < currentLevel - 1; i++){
			fprintf(file, "    ");
		}
		fprintf(file, "%*d:%s\n", level * 4, currentLevel - 1, root->data.c_str());
	}else if(level > 1){
		printLevelOrder(root->left, level - 1, file, currentLevel);
		printLevelOrder(root->right, level - 1, file, currentLevel);
	}
}
