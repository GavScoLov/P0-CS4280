#ifndef TRAVERSALS_H
#define TRAVERSALS_H

#include <iostream>

#include "buildTree.h"
#include "node.h"

void traverseLevelOrder(BSTNode* root, int level, FILE* file);
void traversePreOrder(BSTNode* root, int level, FILE* file);
void traversePostOrder(BSTNode* root, int level, FILE* file);
void printLevelOrder(BSTNode* root, int level, FILE* file, int currentLevel);
void printNode(BSTNode* root, int level, FILE* file);

#endif
