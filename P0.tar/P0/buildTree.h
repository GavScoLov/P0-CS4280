#ifndef BUILDTREE_H
#define BUILDTREE_H

#include <iostream>
#include <string>

#include "node.h"

using namespace std;

const int MAX = 100;

// Structure for BST Node
struct BSTNode {
	string data;
	BSTNode* left;
	BSTNode* right;
	BSTNode(const string& str) : data(str), left(NULL), right(NULL) {}
};

typedef struct {
	node_t *root;
} tree_t;

extern char fileArr[MAX];
extern char fileWord[MAX];
extern char capitalLtr[MAX];   // Array of Capital Letters
extern string words[MAX];      // Array of Words from File
extern string nodeArr[MAX];    // Array of Nodes that contain '<CapitalLetters>: <Words>'

node_t* buildTree(char*, char*, int);

#endif
